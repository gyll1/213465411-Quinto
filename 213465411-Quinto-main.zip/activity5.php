<!-- Activity 5: Sum of Numbers -->
<div>
    <h2>Activity 5: Sum of Numbers</h2>
    <pre>
<?php
$sum = 0;
$l = 1;
while ($l <= 100) {
    $sum += $l;
    $l++;
}
echo "The sum of numbers from 1 to 100 is: $sum";
?>
    </pre>
</div>
<hr>
