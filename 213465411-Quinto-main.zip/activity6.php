<!-- Activity 6: Array Iteration with foreach -->
<div>
    <h2>Activity 6: Array Iteration with foreach</h2>
    <pre>
<?php
$movies = ["The Shawshank Redemption", "Inception", "The Dark Knight", "Interstellar", "Parasite"];
foreach ($movies as $index => $movie) {
    echo ($index + 1) . ". $movie\n";
}
?>
    </pre>
</div>
<hr>