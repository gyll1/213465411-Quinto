<!-- Activity 3: Multiplication Table -->
<div>
    <h2>Activity 3: Multiplication Table</h2>
    <pre>
<?php
for ($j = 1; $j <= 10; $j++) {
    echo "7 x $j = " . (7 * $j) . "\n";
}
?>
    </pre>
</div>
<hr>