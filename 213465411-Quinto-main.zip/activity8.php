<!-- Activity 8: Factorial Calculator -->
<div>
    <h2>Activity 8: Factorial Calculator</h2>
    <h3>Factorial of 5:</h3>
    <pre>
<?php
$factorial = 1;
$n = 5;
for ($m = 1; $m <= $n; $m++) {
    $factorial *= $m;
}
echo "Factorial of $n is: $factorial";
?>
    </pre>
</div>
<hr>