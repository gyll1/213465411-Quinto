<!-- Activity 7: Key-Value Pairs with foreach -->
<div>
    <h2>Activity 7: Key-Value Pairs with foreach</h2>
    <pre>
<?php
$student = [
    "Name" => "Alice",
    "Age" => 20,
    "Grade" => "A",
    "City" => "Baguio"
];
foreach ($student as $key => $value) {
    echo "$key: $value\n";
}
?>
    </pre>
</div>
<hr>